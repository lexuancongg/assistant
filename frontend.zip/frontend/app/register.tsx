"use client"

import { useState } from "react";
import authenticationService from "@/services/auth/authenticationService";
import { useRouter } from 'next/navigation';

export default function RegisterPage(){
    const [username,setUsername] = useState('');
    const [password,setPassword] = useState('');
    const [email,setEmail] = useState('');
    const [error,setError] = useState<string | null>(null);
    const router = useRouter();

    const handleRegister = (e:React.FormEvent) => {
        e.preventDefault();
        setError(null);
        authenticationService.register({username, password, email})
            .then(()=>{
                router.push('/(auth)/login');
            })
            .catch(async (res)=>{
                try{
                    if(res instanceof Response){
                        const j = await res.json().catch(()=>null);
                        setError(j?.message || 'Đăng ký thất bại');
                    }else{
                        setError('Đăng ký thất bại');
                    }
                }catch(e){setError('Đăng ký thất bại')}
            });
    }

    return (
        <div className="min-h-screen flex items-center justify-center bg-gray-100">
            <div className="bg-white p-8 rounded-lg shadow w-[420px]">
                <h1 className="text-2xl font-bold text-center mb-6">Đăng ký</h1>
                <form onSubmit={handleRegister} className="flex flex-col gap-4">
                    <div>
                        <label className="text-sm text-gray-600">Username</label>
                        <input value={username} onChange={e=>setUsername(e.target.value)} className="w-full border rounded px-3 py-2 mt-1" required />
                    </div>
                    <div>
                        <label className="text-sm text-gray-600">Email (tùy chọn)</label>
                        <input value={email} onChange={e=>setEmail(e.target.value)} className="w-full border rounded px-3 py-2 mt-1" />
                    </div>
                    <div>
                        <label className="text-sm text-gray-600">Mật khẩu</label>
                        <input value={password} onChange={e=>setPassword(e.target.value)} type="password" className="w-full border rounded px-3 py-2 mt-1" required />
                    </div>

                    {error && <div className="text-red-600 text-sm">{error}</div>}

                    <button type="submit" className="bg-blue-600 text-white py-2 rounded">Đăng ký</button>
                </form>

                <p className="text-xs text-gray-400 mt-3">Đã có tài khoản? <a href="/(auth)/login" className="text-blue-600">Đăng nhập</a></p>
            </div>
        </div>
    )
}