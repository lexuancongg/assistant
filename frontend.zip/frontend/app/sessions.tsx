"use client"

import { useEffect, useState } from "react";
import chatService from "@/services/chat/chatService";
import { useRouter } from 'next/navigation';

type SessionItem = {
    sessionId: number;
    title: string;
    assistantPersona?: string;
    favorite?: boolean;
    documentId?: number | null;
    documentName?: string | null;
    messageCount?: number;
}

export default function SessionsPage(){
    const [sessions, setSessions] = useState<SessionItem[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const router = useRouter();

    useEffect(()=>{
        setLoading(true);
        chatService.listSessions()
            .then((res:any)=>{
                setSessions(res || []);
            })
            .catch((e)=>{
                console.error('listSessions error',e);
                setError('Không tải được danh sách sessions');
            })
            .finally(()=>setLoading(false));
    },[]);

    return (
        <div className="p-6">
            <h2 className="text-xl font-semibold mb-4">Danh sách phiên chat</h2>
            {loading && <div>Đang tải...</div>}
            {error && <div className="text-red-600">{error}</div>}
            {!loading && sessions.length === 0 && <div>Không có phiên nào.</div>}
            <div className="space-y-3">
                {sessions.map((s:any)=> (
                    <div key={s.sessionId} className="p-3 border rounded flex items-center justify-between">
                        <div>
                            <div className="font-medium">{s.title ?? `Session ${s.sessionId}`}</div>
                            <div className="text-sm text-gray-500">{s.documentName ? `Tài liệu: ${s.documentName}` : 'Không có tài liệu'}</div>
                            <div className="text-sm text-gray-400">Persona: {s.assistantPersona ?? 'Mặc định'} • Messages: {s.messageCount ?? 0}</div>
                        </div>
                        <div className="flex gap-2">
                            <button onClick={()=>{
                                if(s.documentId){
                                    router.push(`/ai/my-documents`);
                                    // open document detail: the UI currently finds selected doc by id, but deep link not implemented
                                } else {
                                    // open chat view (not fully implemented)
                                }
                            }} className="px-3 py-1 bg-blue-600 text-white rounded text-sm">Mở</button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    )
}