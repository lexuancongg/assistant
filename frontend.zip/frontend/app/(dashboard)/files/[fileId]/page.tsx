'use client';
import { useState } from 'react';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import { ChevronLeft, Sparkles, Users, MoreVertical, X, FileText } from 'lucide-react';
import { usePageBreadcrumb } from '@/lib/breadcrumb-context';
import FileTypeIcon from '@/components/files/FileTypeIcon';
import { FILES, PERMISSION_ENTRIES } from '@/lib/fake-data';
import type { PermissionLevel } from '@/lib/types';

const TABS = ['Thông tin', 'Nội dung', 'AI Summary', 'Lịch sử', 'Quyền truy cập'] as const;
type Tab = (typeof TABS)[number];

type AccessScope = 'Riêng tư' | 'Hạn chế' | 'Toàn công ty';

export default function FileDetailPage() {
    const params = useParams<{ fileId: string }>();
    const file = FILES.find((f) => f.id === params.fileId) ?? FILES[0];
    usePageBreadcrumb(['Tất cả file', file.name]);
    const [activeTab, setActiveTab] = useState<Tab>('Thông tin');

    // --- state cho tab Quyền truy cập ---
    const [shareTarget, setShareTarget] = useState('');
    const [shareLevel, setShareLevel] = useState<PermissionLevel>('Viewer');
    const [showPermissionModal, setShowPermissionModal] = useState(false);

    return (
        <div className="px-6 pt-5 pb-6">
            <Link href="/files" className="inline-flex items-center gap-1 text-sm text-gray-400 hover:text-gray-600 transition-colors mb-3">
                <ChevronLeft className="w-4 h-4" strokeWidth={2} />
                Tất cả file
            </Link>

            <div className="bg-white rounded-xl border border-gray-200">
                <div className="flex items-center gap-3 px-5 pt-5 pb-4">
                    <div className="w-11 h-11 rounded-lg bg-red-50 flex items-center justify-center shrink-0">
                        <FileTypeIcon type={file.type} className="w-5 h-5" />
                    </div>
                    <div className="min-w-0">
                        <h1 className="text-base font-semibold text-gray-900 truncate">{file.name}</h1>
                        <p className="text-xs text-gray-400 mt-0.5">
                            {file.size} · {file.type.toUpperCase()}
                        </p>
                        <p className="text-xs text-gray-400">
                            Upload bởi {file.uploadedByName} · {file.updatedAt}
                        </p>
                    </div>
                </div>

                <div className="flex items-center gap-1 px-5 border-b border-gray-100">
                    {TABS.map((tab) => (
                        <button
                            key={tab}
                            onClick={() => setActiveTab(tab)}
                            className={`px-3 py-2.5 text-sm font-medium border-b-2 -mb-px transition-colors ${
                                activeTab === tab
                                    ? 'border-blue-600 text-blue-600'
                                    : 'border-transparent text-gray-500 hover:text-gray-700'
                            }`}
                        >
                            {tab}
                        </button>
                    ))}
                </div>

                <div className="p-5">
                    {activeTab === 'Thông tin' && (
                        <div className="grid grid-cols-2 gap-6">
                            <div>
                                <dl className="flex flex-col gap-3 text-sm">
                                    <div className="flex">
                                        <dt className="w-28 text-gray-400 shrink-0">Tên file</dt>
                                        <dd className="text-gray-800">{file.name}</dd>
                                    </div>
                                    <div className="flex">
                                        <dt className="w-28 text-gray-400 shrink-0">Loại file</dt>
                                        <dd className="text-gray-800 uppercase">{file.type}</dd>
                                    </div>
                                    <div className="flex">
                                        <dt className="w-28 text-gray-400 shrink-0">Kích thước</dt>
                                        <dd className="text-gray-800">{file.size}</dd>
                                    </div>
                                    <div className="flex">
                                        <dt className="w-28 text-gray-400 shrink-0">Đường dẫn</dt>
                                        <dd className="text-gray-800 truncate">{file.path ?? '/'}</dd>
                                    </div>
                                    <div className="flex">
                                        <dt className="w-28 text-gray-400 shrink-0">Tags</dt>
                                        <dd className="flex flex-wrap gap-1.5">
                                            {(file.tags ?? []).map((tag) => (
                                                <span key={tag} className="px-2 py-0.5 rounded-full bg-blue-50 text-blue-600 text-xs">
                                                    {tag}
                                                </span>
                                            ))}
                                        </dd>
                                    </div>
                                    <div className="flex">
                                        <dt className="w-28 text-gray-400 shrink-0">Mô tả</dt>
                                        <dd className="text-gray-800">Hợp đồng lao động ký ngày 01/06/2024</dd>
                                    </div>
                                </dl>
                            </div>

                            <div className="bg-gray-50 rounded-xl p-4">
                                <div className="flex items-center gap-1.5 text-sm font-medium text-gray-800 mb-2">
                                    <Sparkles className="w-4 h-4 text-blue-500" strokeWidth={2} />
                                    AI Summary
                                </div>
                                <p className="text-sm text-gray-600 leading-relaxed">
                                    Hợp đồng lao động không xác định thời hạn giữa Công ty Rikai Technology và ông Trần Văn Nam ở vị trí Kỹ sư phần mềm, mức lương 25,000,000 VNĐ/tháng...
                                </p>
                                <button
                                    onClick={() => setActiveTab('AI Summary')}
                                    className="mt-3 px-3 py-1.5 rounded-lg bg-white border border-gray-200 text-xs font-medium text-gray-700 hover:bg-gray-50 transition-colors"
                                >
                                    Xem chi tiết
                                </button>
                            </div>
                        </div>
                    )}

                    {activeTab === 'Nội dung' && (
                        <p className="text-sm text-gray-500">Xem trước nội dung file — tích hợp trình xem PDF/Office ở đây.</p>
                    )}

                    {activeTab === 'AI Summary' && (
                        <div className="max-w-2xl">
                            <p className="text-sm text-gray-800 font-medium mb-2">Tóm tắt hợp đồng lao động với {file.uploadedByName}:</p>
                            <ul className="flex flex-col gap-1.5 text-sm text-gray-600">
                                <li>• Loại hợp đồng: Hợp đồng lao động không xác định thời hạn</li>
                                <li>• Chức danh: Kỹ sư phần mềm</li>
                                <li>• Ngày bắt đầu: 01/06/2024</li>
                                <li>• Mức lương: 25,000,000 VNĐ/tháng</li>
                                <li>• Thời gian thử việc: 02 tháng</li>
                            </ul>
                        </div>
                    )}

                    {activeTab === 'Lịch sử' && (
                        <p className="text-sm text-gray-500">Lịch sử phiên bản và chỉnh sửa của file sẽ hiển thị ở đây.</p>
                    )}

                    {activeTab === 'Quyền truy cập' && (
                        <div className="max-w-2xl">
                            <div className="flex items-center justify-between mb-2">
                                <p className="text-sm font-medium text-gray-700">Chia sẻ với người dùng/nhóm</p>
                                <button
                                    onClick={() => setShowPermissionModal(true)}
                                    className="px-3 py-1.5 rounded-lg bg-gray-900 text-xs font-medium text-white hover:bg-gray-800 transition-colors"
                                >
                                    Thiết lập phân quyền
                                </button>
                            </div>

                            <div className="flex items-center gap-2">
                                <input
                                    value={shareTarget}
                                    onChange={(e) => setShareTarget(e.target.value)}
                                    placeholder="Tìm kiếm người dùng hoặc nhóm..."
                                    className="flex-1 px-3 py-2 rounded-lg border border-gray-200 text-sm outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-100 transition-colors"
                                />
                                <select
                                    value={shareLevel}
                                    onChange={(e) => setShareLevel(e.target.value as PermissionLevel)}
                                    className="px-3 py-2 rounded-lg border border-gray-200 text-sm text-gray-700 outline-none"
                                >
                                    <option value="Viewer">Viewer</option>
                                    <option value="Editor">Editor</option>
                                </select>
                                <button
                                    onClick={() => {
                                        // TODO: gọi API chia sẻ, ví dụ POST /api/files/{fileId}/permissions { target: shareTarget, level: shareLevel }
                                        console.log('Chia sẻ với', shareTarget, shareLevel);
                                        setShareTarget('');
                                    }}
                                    disabled={!shareTarget.trim()}
                                    className="px-4 py-2 rounded-lg bg-blue-600 text-sm font-medium text-white hover:bg-blue-700 disabled:opacity-40 transition-colors shrink-0"
                                >
                                    Chia sẻ
                                </button>
                            </div>

                            <p className="text-sm font-medium text-gray-700 mt-6 mb-2">Đã chia sẻ</p>
                            <div className="flex flex-col divide-y divide-gray-50">
                                {PERMISSION_ENTRIES.map((entry) => (
                                    <div key={entry.id} className="flex items-center gap-3 py-2.5">
                                        <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${entry.avatarColor}`}>
                                            {entry.subjectType === 'group' ? (
                                                <Users className="w-4 h-4" strokeWidth={2} />
                                            ) : (
                                                <span className="text-xs font-bold">{entry.avatarInitial}</span>
                                            )}
                                        </div>
                                        <div className="flex-1 min-w-0">
                                            <p className="text-sm text-gray-800 truncate">{entry.name}</p>
                                            <p className="text-xs text-gray-400 truncate">{entry.subtitle}</p>
                                        </div>
                                        <span className="text-sm text-gray-500 shrink-0">{entry.level}</span>
                                        <button className="p-1 rounded hover:bg-gray-100 text-gray-400 hover:text-gray-600 transition-colors shrink-0" aria-label="Tùy chọn">
                                            <MoreVertical className="w-4 h-4" strokeWidth={2} />
                                        </button>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}
                </div>
            </div>

            {showPermissionModal && (
                <PermissionModal file={file} onClose={() => setShowPermissionModal(false)} />
            )}
        </div>
    );
}

function PermissionModal({ file, onClose }: { file: (typeof FILES)[number]; onClose: () => void }) {
    const [scope, setScope] = useState<AccessScope>('Hạn chế');
    // TODO: thay bằng dữ liệu thật (grantees) khi có API — tạm giữ 2 dòng mẫu như PERMISSION_ENTRIES
    const grantees = PERMISSION_ENTRIES.slice(0, 2);

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 px-4">
            <div className="bg-white rounded-xl w-full max-w-md p-5">
                <div className="flex items-center justify-between mb-3">
                    <h2 className="text-base font-semibold text-gray-900">Phân quyền truy cập</h2>
                    <button onClick={onClose} className="p-1 rounded hover:bg-gray-100 text-gray-400 hover:text-gray-600 transition-colors" aria-label="Đóng">
                        <X className="w-4 h-4" strokeWidth={2} />
                    </button>
                </div>

                <div className="flex items-center gap-1.5 text-sm text-gray-600 mb-4">
                    <FileText className="w-4 h-4 text-gray-400" strokeWidth={2} />
                    {file.name}
                </div>

                <p className="text-xs text-gray-400 mb-2">Mức truy cập</p>
                <div className="grid grid-cols-3 gap-2 mb-4">
                    {(['Riêng tư', 'Hạn chế', 'Toàn công ty'] as AccessScope[]).map((opt) => (
                        <button
                            key={opt}
                            onClick={() => setScope(opt)}
                            className={`px-3 py-2 rounded-lg border text-sm font-medium transition-colors ${
                                scope === opt
                                    ? 'border-blue-500 text-blue-600 bg-blue-50'
                                    : 'border-gray-200 text-gray-600 hover:bg-gray-50'
                            }`}
                        >
                            {opt}
                        </button>
                    ))}
                </div>

                <p className="text-xs text-gray-400 mb-2">Được truy cập bởi</p>
                <div className="flex flex-col divide-y divide-gray-50 border border-gray-100 rounded-lg mb-4">
                    {grantees.map((entry) => (
                        <div key={entry.id} className="flex items-center gap-2.5 px-3 py-2.5">
                            <div className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 ${entry.avatarColor}`}>
                                {entry.subjectType === 'group' ? (
                                    <Users className="w-3.5 h-3.5" strokeWidth={2} />
                                ) : (
                                    <span className="text-[11px] font-bold">{entry.avatarInitial}</span>
                                )}
                            </div>
                            <span className="flex-1 text-sm text-gray-800 truncate">{entry.name}</span>
                            <span className="text-xs text-gray-400 shrink-0">{entry.level === 'Editor' ? 'Chỉnh sửa' : 'Xem & tải'}</span>
                        </div>
                    ))}
                </div>

                <div className="flex items-start gap-2 rounded-lg bg-amber-50 border border-amber-200 px-3 py-2.5 mb-5">
                    <span className="text-amber-500 mt-0.5">ⓘ</span>
                    <p className="text-xs text-amber-700 leading-relaxed">
                        Trợ lý AI sẽ chỉ trích dẫn file này cho người dùng thuộc danh sách trên
                    </p>
                </div>

                <div className="flex justify-end gap-2">
                    <button onClick={onClose} className="px-4 py-2 rounded-lg border border-gray-200 text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors">
                        Hủy
                    </button>
                    <button
                        onClick={() => {
                            // TODO: PATCH /api/files/{file.id}/permissions { scope, grantees }
                            onClose();
                        }}
                        className="px-4 py-2 rounded-lg bg-gray-900 text-sm font-medium text-white hover:bg-gray-800 transition-colors"
                    >
                        Lưu thay đổi
                    </button>
                </div>
            </div>
        </div>
    );
}