'use client';
import { useMemo, useState } from 'react';
import Link from 'next/link';
import { FolderPlus, Upload, MoreVertical, Search, ShieldCheck } from 'lucide-react';
import { usePageBreadcrumb } from '@/lib/breadcrumb-context';
import FolderTree from '@/components/files/FolderTree';
import FileTypeIcon from '@/components/files/FileTypeIcon';
import PermissionModal from '@/components/files/PermissionModal';
import { CreateFolderModal, UploadFileModal } from '@/components/files/FileModals';
import { FILES, FOLDER_TREE } from '@/lib/fake-data';

// Lấy id của folder được chọn + toàn bộ folder con (để search trong "Hợp đồng" cũng ra file ở "Năm 2024/2025")
function getDescendantIds(id: string): string[] {
    const findNode = (nodes: typeof FOLDER_TREE, targetId: string): any => {
        for (const n of nodes) {
            if (n.id === targetId) return n;
            if (n.children) {
                const found = findNode(n.children, targetId);
                if (found) return found;
            }
        }
        return null;
    };
    const collectIds = (node: any): string[] => {
        if (!node) return [];
        const childIds = (node.children ?? []).flatMap(collectIds);
        return [node.id, ...childIds];
    };
    return collectIds(findNode(FOLDER_TREE, id));
}

// Đếm số thư mục con trực tiếp + toàn bộ nhánh (dùng cho dòng "Áp dụng cho N file, M thư mục con")
function countDescendantFolders(id: string): number {
    const findNode = (nodes: typeof FOLDER_TREE, targetId: string): any => {
        for (const n of nodes) {
            if (n.id === targetId) return n;
            if (n.children) {
                const found = findNode(n.children, targetId);
                if (found) return found;
            }
        }
        return null;
    };
    const countAll = (node: any): number => {
        if (!node?.children) return 0;
        return node.children.length + node.children.reduce((sum: number, c: any) => sum + countAll(c), 0);
    };
    return countAll(findNode(FOLDER_TREE, id));
}

const FILE_TYPES = [
    { value: 'all', label: 'Tất cả loại' },
    { value: 'pdf', label: 'PDF' },
    { value: 'docx', label: 'Word' },
    { value: 'xlsx', label: 'Excel' },
    { value: 'pptx', label: 'PowerPoint' },
    { value: 'txt', label: 'Văn bản' },
];

export default function FilesPage() {
    usePageBreadcrumb(['Quản lý file']);
    const [selectedFolder, setSelectedFolder] = useState('all');
    const [selectedFolderName, setSelectedFolderName] = useState('Tất cả file');
    const [searchTerm, setSearchTerm] = useState('');
    const [typeFilter, setTypeFilter] = useState('all');
    const [showCreateFolder, setShowCreateFolder] = useState(false);
    const [showUploadFile, setShowUploadFile] = useState(false);
    const [showPermissionModal, setShowPermissionModal] = useState(false);

    const usedGb = 2.4;
    const totalGb = 10;
    const usedPct = Math.round((usedGb / totalGb) * 100);

    const filteredFiles = useMemo(() => {
        const scopedIds = selectedFolder === 'all' ? null : getDescendantIds(selectedFolder);
        return FILES.filter((file) => {
            const inFolder = scopedIds ? scopedIds.includes(file.folderId) : true;
            const matchesName = file.name.toLowerCase().includes(searchTerm.trim().toLowerCase());
            const matchesType = typeFilter === 'all' || file.type === typeFilter;
            return inFolder && matchesName && matchesType;
        });
    }, [selectedFolder, searchTerm, typeFilter]);

    return (
        <div className="px-6 pt-3 h-[calc(100vh-64px)] flex flex-col">
            <div className="flex items-center justify-between mb-4">
                <div />
                <div className="flex items-center gap-2">
                    {selectedFolder !== 'all' && (
                        <button
                            onClick={() => setShowPermissionModal(true)}
                            className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-gray-200 text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors"
                        >
                            <ShieldCheck className="w-4 h-4" strokeWidth={2} />
                            Quản lý quyền truy cập
                        </button>
                    )}
                    <button
                        onClick={() => setShowCreateFolder(true)}
                        className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-gray-200 text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors"
                    >
                        <FolderPlus className="w-4 h-4" strokeWidth={2} />
                        Tạo thư mục
                    </button>
                    <button
                        onClick={() => setShowUploadFile(true)}
                        className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-blue-600 text-sm font-medium text-white hover:bg-blue-700 transition-colors"
                    >
                        <Upload className="w-4 h-4" strokeWidth={2} />
                        Upload file
                    </button>
                </div>
            </div>

            <div className="flex gap-4 flex-1 min-h-0">
                <FolderTree
                    selectedId={selectedFolder}
                    onSelect={(id, name) => {
                        setSelectedFolder(id);
                        setSelectedFolderName(name);
                    }}
                    onManagePermission={(id, name) => {
                        setSelectedFolder(id);
                        setSelectedFolderName(name);
                        setShowPermissionModal(true);
                    }}
                />

                <div className="flex-1 bg-white rounded-xl border border-gray-200 flex flex-col min-w-0">
                    <div className="px-5 pt-4 pb-3 flex items-center justify-between gap-3 flex-wrap">
                        <h2 className="text-base font-semibold text-gray-900">{selectedFolderName}</h2>
                        <div className="flex items-center gap-2">
                            <div className="relative">
                                <Search className="w-4 h-4 text-gray-400 absolute left-2.5 top-1/2 -translate-y-1/2" strokeWidth={2} />
                                <input
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                    placeholder={
                                        selectedFolder === 'all'
                                            ? 'Tìm trong tất cả file...'
                                            : `Tìm trong "${selectedFolderName}"...`
                                    }
                                    className="pl-8 pr-3 py-1.5 text-sm border border-gray-200 rounded-lg w-64 focus:outline-none focus:ring-1 focus:ring-blue-500"
                                />
                            </div>
                            <select
                                value={typeFilter}
                                onChange={(e) => setTypeFilter(e.target.value)}
                                className="text-sm border border-gray-200 rounded-lg px-2.5 py-1.5 text-gray-700 focus:outline-none focus:ring-1 focus:ring-blue-500"
                            >
                                {FILE_TYPES.map((t) => (
                                    <option key={t.value} value={t.value}>
                                        {t.label}
                                    </option>
                                ))}
                            </select>
                        </div>
                    </div>
                    <div className="flex-1 overflow-auto">
                        <table className="w-full text-sm">
                            <thead>
                            <tr className="text-left text-xs text-gray-400 border-y border-gray-100">
                                <th className="font-medium px-5 py-2.5">Tên</th>
                                <th className="font-medium px-5 py-2.5">Chủ sở hữu</th>
                                <th className="font-medium px-5 py-2.5">Người tải lên</th>
                                <th className="font-medium px-5 py-2.5">Cập nhật</th>
                                <th className="font-medium px-5 py-2.5">Kích thước</th>
                                <th className="font-medium px-5 py-2.5 w-8"></th>
                            </tr>
                            </thead>
                            <tbody>
                            {filteredFiles.map((file) => (
                                <tr key={file.id} className="border-b border-gray-50 last:border-0 hover:bg-gray-50/60 transition-colors">
                                    <td className="px-5 py-2.5">
                                        <Link href={`/files/${file.id}`} className="flex items-center gap-2 min-w-0">
                                            <FileTypeIcon type={file.type} />
                                            <span className="text-gray-800 truncate hover:text-blue-600 transition-colors">{file.name}</span>
                                        </Link>
                                    </td>
                                    <td className="px-5 py-2.5 text-gray-600 whitespace-nowrap">{file.owner}</td>
                                    <td className="px-5 py-2.5">
                                        <div className="min-w-0">
                                            <p className="text-gray-700 truncate">{file.uploadedByName}</p>
                                            <p className="text-xs text-gray-400 truncate">{file.uploadedByEmail}</p>
                                        </div>
                                    </td>
                                    <td className="px-5 py-2.5 text-gray-500 whitespace-nowrap">{file.updatedAt}</td>
                                    <td className="px-5 py-2.5 text-gray-500 whitespace-nowrap">{file.size}</td>
                                    <td className="px-5 py-2.5">
                                        <button className="p-1 rounded hover:bg-gray-100 text-gray-400 hover:text-gray-600 transition-colors">
                                            <MoreVertical className="w-4 h-4" strokeWidth={2} />
                                        </button>
                                    </td>
                                </tr>
                            ))}
                            {filteredFiles.length === 0 && (
                                <tr>
                                    <td colSpan={6} className="px-5 py-10 text-center text-gray-400">
                                        Không tìm thấy file phù hợp
                                    </td>
                                </tr>
                            )}
                            </tbody>
                        </table>
                    </div>

                    <div className="px-5 py-3 border-t border-gray-100 flex items-center gap-3">
                        <span className="text-sm text-gray-500 whitespace-nowrap">
                            Đã sử dụng: {usedGb} GB / {totalGb} GB
                        </span>
                        <div className="flex-1 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                            <div className="h-full bg-blue-500 rounded-full" style={{ width: `${usedPct}%` }} />
                        </div>
                        <span className="text-sm text-gray-500">{usedPct}%</span>
                    </div>
                </div>
            </div>

            {showCreateFolder && (
                <CreateFolderModal
                    parentFolderName={selectedFolderName}
                    onClose={() => setShowCreateFolder(false)}
                    onCreate={(name) => {
                        console.log('Tạo thư mục:', name, 'trong', selectedFolder);
                    }}
                />
            )}

            {showUploadFile && (
                <UploadFileModal
                    parentFolderName={selectedFolderName}
                    onClose={() => setShowUploadFile(false)}
                    onUpload={(files) => {
                        console.log('Upload files:', files, 'vào', selectedFolder);
                    }}
                />
            )}

            {showPermissionModal && selectedFolder !== 'all' && (
                <PermissionModal
                    target={{
                        type: 'folder',
                        id: selectedFolder,
                        name: selectedFolderName,
                        childFileCount: filteredFiles.length,
                        childFolderCount: countDescendantFolders(selectedFolder),
                    }}
                    onClose={() => setShowPermissionModal(false)}
                />
            )}
        </div>
    );
}