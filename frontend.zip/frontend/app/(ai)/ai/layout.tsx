'use client';
import { useState } from 'react';
import Sidebar from '@/components/common/sidebar';
import Topbar from '@/components/common/topbar';

export default function Layout({ children }: { children: React.ReactNode }) {
    const [sidebarOpen, setSidebarOpen] = useState(true);

    return (
        <div className="flex h-screen overflow-hidden">
            <Sidebar isOpen={sidebarOpen} setIsOpen={setSidebarOpen} />
            <div
                className={`flex flex-col flex-1 min-w-0 h-screen transition-all duration-300 ease-in-out ${
                    sidebarOpen ? 'ml-56' : 'ml-16'
                }`}
            >
                <Topbar />
                <main className="flex-1 min-h-0 overflow-hidden">
                    {children}
                </main>
            </div>
        </div>
    );
}