'use client';
import {
    Upload, ScanLine, MessageSquare, Share2, Cog, Send, Mic,
    FileText, TrendingUp, TrendingDown, MoreHorizontal, Sparkles, X, ArrowRight,
} from 'lucide-react';

const stats = [
    { label: 'Tài liệu', value: '2.580', change: '+12%', trend: 'up', icon: FileText, color: 'indigo' },
    { label: 'Hợp đồng', value: '430', change: '+8%', trend: 'up', icon: FileText, color: 'emerald' },
    { label: 'Hóa đơn', value: '152', change: '-5%', trend: 'down', icon: FileText, color: 'orange' },
    { label: 'Email', value: '320', change: '+15%', trend: 'up', icon: FileText, color: 'purple' },
];

const quickActions = [
    { label: 'Tải tài liệu lên', desc: 'PDF, DOCX, XLSX...', icon: Upload, color: 'indigo' },
    { label: 'Quét OCR', desc: 'Trích xuất nội dung', icon: ScanLine, color: 'blue' },
    { label: 'Chat với AI', desc: 'Hỏi và nhận câu trả lời', icon: MessageSquare, color: 'green' },
    { label: 'Knowledge Graph', desc: 'Khám phá mối liên kết', icon: Share2, color: 'purple' },
    { label: 'Automation', desc: 'Tự động hoá quy trình', icon: Cog, color: 'orange' },
];

const documents = [
    { name: 'Hợp đồng lao động.pdf', type: 'Contract', typeColor: 'red', source: 'Upload', updated: '2 giờ trước', size: '108.97 KB', summary: true },
    { name: 'Invoice_2025_06.xlsx', type: 'Invoice', typeColor: 'green', source: 'Email', updated: '5 giờ trước', size: '1.32 MB', summary: true },
    { name: 'Báo cáo dự án Q2.docx', type: 'Report', typeColor: 'blue', source: 'Upload', updated: 'Hôm qua', size: '2.15 MB', summary: true },
    { name: 'Email từ ABC Corp.eml', type: 'Email', typeColor: 'purple', source: 'Email', updated: '2 ngày trước', size: '98.3 KB', summary: false },
];

const chatHistory = [
    { group: 'Hôm nay', items: [
            { text: 'Hợp đồng với ABC ký trong năm 2025', time: '10:30 AM' },
            { text: 'Hóa đơn chưa thanh toán trong tháng 6', time: '09:15 AM' },
        ]},
    { group: 'Hôm qua', items: [
            { text: 'Điều khoản thanh toán trong hợp đồng', time: '04:45 PM' },
        ]},
    { group: 'Tuần trước', items: [
            { text: 'Tổng giá trị hợp đồng trong quý 2', time: '11/07/2025' },
        ]},
];

const insights = [
    { text: '5 hợp đồng sẽ hết hạn trong 30 ngày', sub: 'Cần xem xét và gia hạn', icon: FileText, color: 'indigo' },
    { text: '12 hóa đơn chưa thanh toán', sub: 'Tổng giá trị 320.500.000 VND', icon: FileText, color: 'orange' },
    { text: '3 hợp đồng có điều khoản tương tự', sub: 'Có thể xem xét hợp nhất', icon: MessageSquare, color: 'green' },
    { text: '8 email cần phản hồi', sub: 'Một số email đã quá hạn phản hồi', icon: MessageSquare, color: 'purple' },
];

const colorMap: Record<string, { bg: string; text: string; border: string; iconBg: string; hoverBorder: string }> = {
    indigo: { bg: 'bg-indigo-50', text: 'text-indigo-600', border: 'border-l-indigo-500', iconBg: 'bg-indigo-100', hoverBorder: 'hover:border-indigo-200' },
    blue: { bg: 'bg-blue-50', text: 'text-blue-600', border: 'border-l-blue-500', iconBg: 'bg-blue-100', hoverBorder: 'hover:border-blue-200' },
    green: { bg: 'bg-green-50', text: 'text-green-600', border: 'border-l-green-500', iconBg: 'bg-green-100', hoverBorder: 'hover:border-green-200' },
    emerald: { bg: 'bg-emerald-50', text: 'text-emerald-600', border: 'border-l-emerald-500', iconBg: 'bg-emerald-100', hoverBorder: 'hover:border-emerald-200' },
    orange: { bg: 'bg-orange-50', text: 'text-orange-600', border: 'border-l-orange-500', iconBg: 'bg-orange-100', hoverBorder: 'hover:border-orange-200' },
    purple: { bg: 'bg-purple-50', text: 'text-purple-600', border: 'border-l-purple-500', iconBg: 'bg-purple-100', hoverBorder: 'hover:border-purple-200' },
    red: { bg: 'bg-red-50', text: 'text-red-600', border: 'border-l-red-500', iconBg: 'bg-red-100', hoverBorder: 'hover:border-red-200' },
};

export default function DashboardPage() {
    return (
        <div className="h-full overflow-y-auto bg-gray-50/50">
            <div className="flex gap-4 p-4">
                {/* ── Main column ── */}
                <div className="flex-1 min-w-0 flex flex-col gap-4">
                    {/* Hero */}
                    <div className="bg-gradient-to-br from-indigo-50 via-white to-blue-50 rounded-2xl border border-gray-100 shadow-sm p-5 relative overflow-hidden">
                        <div className="relative z-10 max-w-xl">
                            <h1 className="text-xl font-bold text-gray-900 flex items-center gap-2">
                                Chào mừng trở lại, Cong! <span>👋</span>
                            </h1>
                            <p className="text-xs text-gray-500 mt-1.5 leading-relaxed">
                                AI Assistant luôn sẵn sàng giúp bạn tìm kiếm, phân tích và khai thác thông tin từ kho tri thức doanh nghiệp.
                            </p>
                        </div>

                        <div className="absolute right-6 top-1/2 -translate-y-1/2 w-40 h-40 rounded-full bg-gradient-to-br from-indigo-200 to-blue-200 opacity-40 blur-3xl" />

                        <div className="relative z-10 mt-5">
                            <div className="flex items-center gap-3 bg-white border border-gray-200 rounded-xl px-4 py-3 shadow-sm">
                                <Sparkles className="w-4 h-4 text-indigo-500 shrink-0" />
                                <input
                                    type="text"
                                    placeholder="Hỏi bất kỳ điều gì về tài liệu của bạn..."
                                    className="flex-1 bg-transparent text-xs text-gray-700 placeholder:text-gray-400 outline-none"
                                />
                                <button className="w-7 h-7 rounded-lg hover:bg-gray-100 flex items-center justify-center text-gray-400 transition-colors">
                                    <Mic className="w-3.5 h-3.5" />
                                </button>
                                <button className="w-8 h-8 rounded-lg bg-indigo-600 hover:bg-indigo-700 flex items-center justify-center text-white transition-colors shrink-0">
                                    <Send className="w-3.5 h-3.5" />
                                </button>
                            </div>
                            <div className="flex flex-wrap gap-2 mt-3">
                                {['Hợp đồng với ABC', 'Hóa đơn tháng 6', 'Email từ khách hàng', 'Điều khoản thanh toán'].map(tag => (
                                    <button
                                        key={tag}
                                        className="px-3 py-1.5 rounded-full bg-white border border-gray-200 text-[11px] font-medium text-gray-600 hover:bg-indigo-50 hover:border-indigo-200 hover:text-indigo-600 transition-colors"
                                    >
                                        {tag}
                                    </button>
                                ))}
                            </div>
                        </div>
                    </div>

                    {/* Stat cards */}
                    <div className="grid grid-cols-4 gap-3">
                        {stats.map(({ label, value, change, trend, icon: Icon, color }) => {
                            const c = colorMap[color];
                            return (
                                <div
                                    key={label}
                                    className={`bg-white rounded-xl border border-gray-100 border-l-4 ${c.border} shadow-sm px-3.5 py-3 flex items-center gap-2.5`}
                                >
                                    <div className={`w-9 h-9 rounded-lg ${c.iconBg} flex items-center justify-center shrink-0`}>
                                        <Icon className={`w-4.5 h-4.5 ${c.text}`} strokeWidth={2.2} />
                                    </div>
                                    <div className="min-w-0">
                                        <div className="flex items-baseline gap-1.5">
                                            <p className="text-base font-bold text-gray-900 leading-none">{value}</p>
                                            <p className={`text-[9px] font-semibold flex items-center gap-0.5 ${
                                                trend === 'up' ? 'text-emerald-600' : 'text-red-500'
                                            }`}>
                                                {trend === 'up' ? <TrendingUp className="w-2.5 h-2.5" /> : <TrendingDown className="w-2.5 h-2.5" />}
                                                {change}
                                            </p>
                                        </div>
                                        <p className="text-[10px] text-gray-500 truncate mt-0.5">{label}</p>
                                    </div>
                                </div>
                            );
                        })}
                    </div>

                    {/* Quick actions */}
                    <div>
                        <h2 className="text-xs font-bold text-gray-800 mb-2.5">Thao tác nhanh</h2>
                        <div className="grid grid-cols-5 gap-3">
                            {quickActions.map(({ label, desc, icon: Icon, color }) => {
                                const c = colorMap[color];
                                return (
                                    <button
                                        key={label}
                                        className={`bg-white rounded-2xl border border-gray-100 shadow-sm p-3.5 text-left ${c.hoverBorder} hover:shadow-md transition-all duration-200 group`}
                                    >
                                        <div className={`w-9 h-9 rounded-xl ${c.iconBg} flex items-center justify-center mb-2.5 group-hover:scale-105 transition-transform`}>
                                            <Icon className={`w-4.5 h-4.5 ${c.text}`} strokeWidth={2.2} />
                                        </div>
                                        <p className="text-xs font-semibold text-gray-800">{label}</p>
                                        <p className="text-[10px] text-gray-400 mt-0.5">{desc}</p>
                                    </button>
                                );
                            })}
                        </div>
                    </div>

                    {/* Recent documents table */}
                    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
                        <div className="flex items-center justify-between px-5 py-3.5 border-b border-gray-100">
                            <h2 className="text-xs font-bold text-gray-800">Tài liệu gần đây</h2>
                            <button className="flex items-center gap-1 text-[11px] font-semibold text-indigo-600 hover:underline">
                                Xem tất cả <ArrowRight className="w-3 h-3" />
                            </button>
                        </div>
                        <table className="w-full">
                            <thead>
                            <tr className="text-[10px] text-gray-400 font-semibold bg-gray-50/50">
                                <th className="text-left px-5 py-2.5">Tên tài liệu</th>
                                <th className="text-left px-3 py-2.5">Loại</th>
                                <th className="text-left px-3 py-2.5">Nguồn</th>
                                <th className="text-left px-3 py-2.5">Cập nhật</th>
                                <th className="text-left px-3 py-2.5">Kích thước</th>
                                <th className="text-left px-3 py-2.5">AI Summary</th>
                                <th className="w-10"></th>
                            </tr>
                            </thead>
                            <tbody>
                            {documents.map((doc, i) => {
                                const c = colorMap[doc.typeColor];
                                return (
                                    <tr key={doc.name} className={`text-xs hover:bg-gray-50/60 transition-colors ${i !== documents.length - 1 ? 'border-b border-gray-50' : ''}`}>
                                        <td className="px-5 py-2.5">
                                            <div className="flex items-center gap-2.5">
                                                <div className={`w-7 h-7 rounded-lg ${c.iconBg} flex items-center justify-center shrink-0`}>
                                                    <FileText className={`w-3.5 h-3.5 ${c.text}`} />
                                                </div>
                                                <span className="font-medium text-gray-800">{doc.name}</span>
                                            </div>
                                        </td>
                                        <td className="px-3 py-2.5">
                                                <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${c.iconBg} ${c.text}`}>
                                                    {doc.type}
                                                </span>
                                        </td>
                                        <td className="px-3 py-2.5 text-gray-500">{doc.source}</td>
                                        <td className="px-3 py-2.5 text-gray-500">{doc.updated}</td>
                                        <td className="px-3 py-2.5 text-gray-500">{doc.size}</td>
                                        <td className="px-3 py-2.5">
                                                <span className={`inline-flex items-center gap-1 text-[10px] font-medium ${doc.summary ? 'text-emerald-600' : 'text-gray-400'}`}>
                                                    <span className={`w-1.5 h-1.5 rounded-full ${doc.summary ? 'bg-emerald-500' : 'bg-gray-300'}`} />
                                                    {doc.summary ? 'Đã có' : 'Chưa có'}
                                                </span>
                                        </td>
                                        <td className="px-3 py-2.5">
                                            <button className="text-gray-300 hover:text-gray-500 transition-colors">
                                                <MoreHorizontal className="w-4 h-4" />
                                            </button>
                                        </td>
                                    </tr>
                                );
                            })}
                            </tbody>
                        </table>
                    </div>
                </div>

                {/* ── Right column ── */}
                <div className="w-80 shrink-0 flex flex-col gap-4">
                    {/* Chat history */}
                    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-3.5">
                        <div className="flex items-center justify-between mb-2.5">
                            <h2 className="text-xs font-bold text-gray-800">Trò chuyện gần đây</h2>
                            <button className="flex items-center gap-1 text-[10px] font-semibold text-indigo-600 hover:underline">
                                + Mới
                            </button>
                        </div>
                        <div className="flex flex-col gap-3 max-h-72 overflow-y-auto">
                            {chatHistory.map(group => (
                                <div key={group.group}>
                                    <p className="text-[10px] font-semibold text-gray-400 mb-1.5">{group.group}</p>
                                    <div className="flex flex-col gap-1">
                                        {group.items.map(item => (
                                            <button
                                                key={item.text}
                                                className="w-full flex items-start gap-2 px-2 py-1.5 rounded-lg hover:bg-indigo-50/60 transition-colors text-left group"
                                            >
                                                <MessageSquare className="w-3 h-3 text-gray-300 group-hover:text-indigo-400 mt-0.5 shrink-0 transition-colors" />
                                                <div className="min-w-0 flex-1">
                                                    <p className="text-[11px] text-gray-700 truncate">{item.text}</p>
                                                    <p className="text-[9px] text-gray-400">{item.time}</p>
                                                </div>
                                            </button>
                                        ))}
                                    </div>
                                </div>
                            ))}
                        </div>
                        <button className="w-full mt-2.5 pt-2.5 border-t border-gray-50 text-[11px] font-semibold text-indigo-600 hover:underline flex items-center justify-center gap-1">
                            Xem tất cả lịch sử trò chuyện <ArrowRight className="w-3 h-3" />
                        </button>
                    </div>

                    {/* AI Insights */}
                    <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-3.5">
                        <div className="flex items-center justify-between mb-2.5">
                            <h2 className="text-xs font-bold text-gray-800">AI Insights</h2>
                            <button className="flex items-center gap-1 text-[10px] font-semibold text-indigo-600 hover:underline">
                                Xem tất cả <ArrowRight className="w-2.5 h-2.5" />
                            </button>
                        </div>
                        <div className="flex flex-col gap-1">
                            {insights.map(({ text, sub, icon: Icon, color }) => {
                                const c = colorMap[color];
                                return (
                                    <button
                                        key={text}
                                        className="w-full flex items-start gap-2.5 px-2 py-2 rounded-lg hover:bg-gray-50 transition-colors text-left"
                                    >
                                        <div className={`w-7 h-7 rounded-lg ${c.iconBg} flex items-center justify-center shrink-0`}>
                                            <Icon className={`w-3.5 h-3.5 ${c.text}`} />
                                        </div>
                                        <div className="min-w-0 flex-1">
                                            <p className="text-[11px] font-medium text-gray-800 leading-snug">{text}</p>
                                            <p className="text-[10px] text-gray-400 mt-0.5">{sub}</p>
                                        </div>
                                    </button>
                                );
                            })}
                        </div>
                    </div>

                    {/* Tip banner */}
                    <div className="bg-gradient-to-br from-indigo-500 to-blue-600 rounded-2xl shadow-sm p-3.5 relative overflow-hidden">
                        <button className="absolute top-3 right-3 text-white/60 hover:text-white transition-colors">
                            <X className="w-3.5 h-3.5" />
                        </button>
                        <Sparkles className="w-4 h-4 text-white mb-2" />
                        <p className="text-xs font-bold text-white">Mẹo sử dụng AI Assistant</p>
                        <p className="text-[11px] text-white/80 mt-1 leading-relaxed">
                            Hãy đặt câu hỏi cụ thể để AI có thể trả lời chính xác hơn.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    );
}