'use client';
import { useState } from 'react';
import {
    Folder,
    FolderOpen,
    ChevronRight,
    FileText,
    FileSpreadsheet,
    FileImage,
    File as FileIcon,
    MoreVertical,
    FolderPlus,
    Upload,
    UploadCloud,
    X,
    LucideIcon,
} from 'lucide-react';

// ── Types ──
type FileType = 'pdf' | 'xlsx' | 'docx' | 'pptx' | 'txt';

interface FolderNode {
    id: string;
    name: string;
    children: FolderNode[];
}

interface FileItem {
    id: number;
    name: string;
    type: FileType;
    owner: string;
    uploadedByName: string;
    uploadedByEmail: string;
    updatedAt: string;
    size: string;
}

// ── Fake folder tree data — thay bằng API sau ──
const FOLDER_TREE: FolderNode[] = [
    {
        id: 'company-docs',
        name: 'Tài liệu công ty',
        children: [
            { id: 'hr', name: 'Nhân sự', children: [] },
            { id: 'finance', name: 'Tài chính', children: [] },
            {
                id: 'projects',
                name: 'Dự án',
                children: [
                    { id: 'project-a', name: 'Dự án A', children: [] },
                    { id: 'project-b', name: 'Dự án B', children: [] },
                ],
            },
        ],
    },
    {
        id: 'contracts',
        name: 'Hợp đồng',
        children: [
            { id: 'contracts-2024', name: 'Năm 2024', children: [] },
            { id: 'contracts-2025', name: 'Năm 2025', children: [] },
        ],
    },
    { id: 'reports', name: 'Báo cáo', children: [] },
    { id: 'personal', name: 'Tài liệu cá nhân', children: [] },
];

// ── Fake file data — thay bằng API sau ──
const FILES: FileItem[] = [
    {
        id: 1,
        name: 'Quy trình tuyển dụng.pdf',
        type: 'pdf',
        owner: 'Phòng Nhân sự',
        uploadedByName: 'Nguyễn Thị Hoa',
        uploadedByEmail: 'hoa.nguyen@company.com',
        updatedAt: '16/05/2024 10:30',
        size: '2.4 MB',
    },
    {
        id: 2,
        name: 'Báo cáo tài chính Q1.xlsx',
        type: 'xlsx',
        owner: 'Phòng Tài chính',
        uploadedByName: 'Trần Văn Minh',
        uploadedByEmail: 'minh.tran@company.com',
        updatedAt: '15/05/2024 09:15',
        size: '1.8 MB',
    },
    {
        id: 3,
        name: 'Hợp đồng khách hàng A.docx',
        type: 'docx',
        owner: 'Phòng Kinh doanh',
        uploadedByName: 'Lê Thị Thu',
        uploadedByEmail: 'thu.le@company.com',
        updatedAt: '14/05/2024 16:45',
        size: '880 KB',
    },
    {
        id: 4,
        name: 'Chính sách bảo mật.pdf',
        type: 'pdf',
        owner: 'Phòng IT',
        uploadedByName: 'Phạm Đức Anh',
        uploadedByEmail: 'anh.pham@company.com',
        updatedAt: '14/05/2024 14:20',
        size: '1.2 MB',
    },
    {
        id: 5,
        name: 'Kế hoạch dự án B.pptx',
        type: 'pptx',
        owner: 'Phòng Dự án',
        uploadedByName: 'Vũ Thị Lan',
        uploadedByEmail: 'lan.vu@company.com',
        updatedAt: '13/05/2024 11:30',
        size: '5.1 MB',
    },
    {
        id: 6,
        name: 'Hướng dẫn sử dụng.txt',
        type: 'txt',
        owner: 'Nguyễn Văn A',
        uploadedByName: 'Nguyễn Văn A',
        uploadedByEmail: 'a.nguyen@company.com',
        updatedAt: '12/05/2024 08:20',
        size: '45 KB',
    },
];

const FILE_ICON_MAP: Record<FileType, { icon: LucideIcon; className: string }> = {
    pdf: { icon: FileText, className: 'text-red-500' },
    xlsx: { icon: FileSpreadsheet, className: 'text-green-600' },
    docx: { icon: FileText, className: 'text-blue-600' },
    pptx: { icon: FileImage, className: 'text-orange-500' },
    txt: { icon: FileIcon, className: 'text-gray-400' },
};

function FileTypeIcon({ type }: { type: FileType }) {
    const entry = FILE_ICON_MAP[type] ?? FILE_ICON_MAP.txt;
    const Icon = entry.icon;
    return <Icon className={`w-4 h-4 shrink-0 ${entry.className}`} strokeWidth={2} />;
}

// ── Cây thư mục đệ quy, mở rộng/thu gọn từng cấp ──
interface TreeNodeProps {
    node: FolderNode;
    depth: number;
    selectedId: string;
    onSelect: (id: string) => void;
}

function TreeNode({ node, depth, selectedId, onSelect }: TreeNodeProps) {
    const [expanded, setExpanded] = useState(depth === 0);
    const hasChildren = node.children.length > 0;
    const isSelected = selectedId === node.id;

    return (
        <div>
            <button
                onClick={() => {
                    onSelect(node.id);
                    if (hasChildren) setExpanded((v) => !v);
                }}
                style={{ paddingLeft: `${depth * 16 + 8}px` }}
                className={`w-full flex items-center gap-1.5 py-1.5 pr-2 rounded-md text-sm transition-colors duration-150 ${
                    isSelected
                        ? 'bg-blue-50 text-blue-700 font-medium'
                        : 'text-gray-600 hover:bg-gray-50'
                }`}
            >
                {hasChildren ? (
                    <ChevronRight
                        className={`w-3.5 h-3.5 shrink-0 text-gray-400 transition-transform duration-150 ${
                            expanded ? 'rotate-90' : ''
                        }`}
                        strokeWidth={2.5}
                    />
                ) : (
                    <span className="w-3.5 shrink-0" />
                )}
                {expanded && hasChildren ? (
                    <FolderOpen className="w-4 h-4 shrink-0 text-blue-500" strokeWidth={2} />
                ) : (
                    <Folder className="w-4 h-4 shrink-0 text-gray-400" strokeWidth={2} />
                )}
                <span className="truncate">{node.name}</span>
            </button>
            {hasChildren && expanded && (
                <div>
                    {node.children.map((child) => (
                        <TreeNode
                            key={child.id}
                            node={child}
                            depth={depth + 1}
                            selectedId={selectedId}
                            onSelect={onSelect}
                        />
                    ))}
                </div>
            )}
        </div>
    );
}

// ── Khung modal dùng chung ──
interface ModalShellProps {
    title: string;
    onClose: () => void;
    children: React.ReactNode;
}

function ModalShell({ title, onClose, children }: ModalShellProps) {
    return (
        <div
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 px-4"
            onClick={onClose}
        >
            <div
                className="w-full max-w-md bg-white rounded-xl shadow-lg"
                onClick={(e) => e.stopPropagation()}
            >
                <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
                    <h3 className="text-base font-semibold text-gray-900">{title}</h3>
                    <button
                        onClick={onClose}
                        className="p-1 rounded hover:bg-gray-100 text-gray-400 hover:text-gray-600 transition-colors"
                        aria-label="Đóng"
                    >
                        <X className="w-4 h-4" strokeWidth={2} />
                    </button>
                </div>
                {children}
            </div>
        </div>
    );
}

// ── Modal tạo thư mục ──
interface CreateFolderModalProps {
    parentFolderName: string;
    onClose: () => void;
    onCreate: (name: string) => void;
}

function CreateFolderModal({ parentFolderName, onClose, onCreate }: CreateFolderModalProps) {
    const [name, setName] = useState('');

    const handleSubmit = () => {
        if (!name.trim()) return;
        onCreate(name.trim());
        onClose();
    };

    return (
        <ModalShell title="Tạo thư mục mới" onClose={onClose}>
            <div className="px-5 py-4">
                <label className="text-sm text-gray-600">Tên thư mục</label>
                <input
                    autoFocus
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSubmit()}
                    placeholder="Nhập tên thư mục"
                    className="mt-1.5 w-full px-3 py-2 rounded-lg border border-gray-200 text-sm text-gray-800 outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-100 transition-colors"
                />
                <p className="mt-2 text-xs text-gray-400">
                    Thư mục sẽ được tạo trong <span className="text-gray-600">{parentFolderName}</span>
                </p>
            </div>
            <div className="flex items-center justify-end gap-2 px-5 py-4 border-t border-gray-100">
                <button
                    onClick={onClose}
                    className="px-3.5 py-2 rounded-lg border border-gray-200 text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors"
                >
                    Hủy
                </button>
                <button
                    onClick={handleSubmit}
                    disabled={!name.trim()}
                    className="px-3.5 py-2 rounded-lg bg-blue-600 text-sm font-medium text-white hover:bg-blue-700 disabled:opacity-40 disabled:hover:bg-blue-600 transition-colors"
                >
                    Tạo thư mục
                </button>
            </div>
        </ModalShell>
    );
}

// ── Modal upload file ──
interface PendingFile {
    id: string;
    file: File;
}

interface UploadFileModalProps {
    parentFolderName: string;
    onClose: () => void;
    onUpload: (files: File[]) => void;
}

function formatFileSize(bytes: number): string {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function UploadFileModal({ parentFolderName, onClose, onUpload }: UploadFileModalProps) {
    const [pendingFiles, setPendingFiles] = useState<PendingFile[]>([]);
    const [isDragging, setIsDragging] = useState(false);

    const addFiles = (fileList: FileList | null) => {
        if (!fileList) return;
        const newOnes: PendingFile[] = Array.from(fileList).map((file) => ({
            id: `${file.name}-${file.size}-${Date.now()}-${Math.random()}`,
            file,
        }));
        setPendingFiles((prev) => [...prev, ...newOnes]);
    };

    const removeFile = (id: string) => {
        setPendingFiles((prev) => prev.filter((f) => f.id !== id));
    };

    const handleSubmit = () => {
        if (pendingFiles.length === 0) return;
        onUpload(pendingFiles.map((f) => f.file));
        onClose();
    };

    return (
        <ModalShell title="Upload file" onClose={onClose}>
            <div className="px-5 py-4">
                <label
                    onDragOver={(e) => {
                        e.preventDefault();
                        setIsDragging(true);
                    }}
                    onDragLeave={() => setIsDragging(false)}
                    onDrop={(e) => {
                        e.preventDefault();
                        setIsDragging(false);
                        addFiles(e.dataTransfer.files);
                    }}
                    className={`flex flex-col items-center justify-center gap-2 py-8 rounded-lg border-2 border-dashed cursor-pointer transition-colors ${
                        isDragging ? 'border-blue-400 bg-blue-50' : 'border-gray-200 hover:bg-gray-50'
                    }`}
                >
                    <UploadCloud className="w-7 h-7 text-gray-400" strokeWidth={1.5} />
                    <p className="text-sm text-gray-600">
                        Kéo thả file vào đây, hoặc <span className="text-blue-600 font-medium">chọn file</span>
                    </p>
                    <p className="text-xs text-gray-400">Hỗ trợ PDF, Word, Excel, PowerPoint, hình ảnh</p>
                    <input
                        type="file"
                        multiple
                        className="hidden"
                        onChange={(e) => addFiles(e.target.files)}
                    />
                </label>

                {pendingFiles.length > 0 && (
                    <div className="mt-3 flex flex-col gap-1.5 max-h-40 overflow-y-auto">
                        {pendingFiles.map(({ id, file }) => (
                            <div
                                key={id}
                                className="flex items-center justify-between gap-2 px-3 py-2 rounded-lg bg-gray-50 text-sm"
                            >
                                <div className="flex items-center gap-2 min-w-0">
                                    <FileIcon className="w-4 h-4 shrink-0 text-gray-400" strokeWidth={2} />
                                    <span className="truncate text-gray-700">{file.name}</span>
                                    <span className="shrink-0 text-xs text-gray-400">{formatFileSize(file.size)}</span>
                                </div>
                                <button
                                    onClick={() => removeFile(id)}
                                    className="shrink-0 p-1 rounded hover:bg-gray-200 text-gray-400 hover:text-gray-600 transition-colors"
                                    aria-label="Xóa file"
                                >
                                    <X className="w-3.5 h-3.5" strokeWidth={2} />
                                </button>
                            </div>
                        ))}
                    </div>
                )}

                <p className="mt-3 text-xs text-gray-400">
                    File sẽ được tải lên <span className="text-gray-600">{parentFolderName}</span>
                </p>
            </div>
            <div className="flex items-center justify-end gap-2 px-5 py-4 border-t border-gray-100">
                <button
                    onClick={onClose}
                    className="px-3.5 py-2 rounded-lg border border-gray-200 text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors"
                >
                    Hủy
                </button>
                <button
                    onClick={handleSubmit}
                    disabled={pendingFiles.length === 0}
                    className="px-3.5 py-2 rounded-lg bg-blue-600 text-sm font-medium text-white hover:bg-blue-700 disabled:opacity-40 disabled:hover:bg-blue-600 transition-colors"
                >
                    Upload {pendingFiles.length > 0 ? `(${pendingFiles.length})` : ''}
                </button>
            </div>
        </ModalShell>
    );
}

export default function FileManagerPage() {
    const [selectedFolder, setSelectedFolder] = useState<string>('all');
    const [showCreateFolder, setShowCreateFolder] = useState(false);
    const [showUploadFile, setShowUploadFile] = useState(false);

    const currentFolderName = selectedFolder === 'all' ? 'Tất cả file' : selectedFolder;

    const usedGb = 2.4;
    const totalGb = 10;
    const usedPct = Math.round((usedGb / totalGb) * 100);

    return (
        <div className="flex-1 flex flex-col bg-gray-50 min-h-screen">
            {/* ── Header ── */}
            <div className="flex items-center justify-between px-6 pt-3 pb-3">
                <div>
                    {/*<h1 className="text-xl font-semibold text-gray-900">Quản lý file</h1>*/}
                    {/*<p className="text-sm text-gray-500 mt-1">*/}
                    {/*    Tổ chức, quản lý và chia sẻ file an toàn trong tổ chức*/}
                    {/*</p>*/}
                </div>
                <div className="flex items-center gap-2">
                    <button
                        onClick={() => setShowCreateFolder(true)}
                        className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-gray-200 text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors"
                    >
                        <FolderPlus className="w-4 h-4" strokeWidth={2} />
                        Tạo thư mục
                    </button>
                    <button
                        onClick={() => setShowUploadFile(true)}
                        className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-blue-600 text-sm font-medium text-white hover:bg-blue-700 transition-colors"
                    >
                        <Upload className="w-4 h-4" strokeWidth={2} />
                        Upload file
                    </button>
                </div>
            </div>

            <div className="flex-1 flex gap-4 px-6 pb-6 min-h-0">
                {/* ── Sidebar cây thư mục ── */}
                <div className="w-72 shrink-0 bg-white rounded-xl border border-gray-200 flex flex-col">
                    <div className="px-3 pt-4 pb-2">
                        <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide px-2">
                            Thư mục
                        </p>
                    </div>
                    <div className="flex-1 overflow-y-auto px-2 pb-3">
                        <button
                            onClick={() => setSelectedFolder('all')}
                            className={`w-full flex items-center gap-1.5 py-1.5 px-2 rounded-md text-sm mb-1 transition-colors duration-150 ${
                                selectedFolder === 'all'
                                    ? 'bg-blue-50 text-blue-700 font-medium'
                                    : 'text-gray-600 hover:bg-gray-50'
                            }`}
                        >
                            <span className="w-3.5 shrink-0" />
                            <Folder className="w-4 h-4 shrink-0 text-gray-400" strokeWidth={2} />
                            Tất cả file
                        </button>
                        {FOLDER_TREE.map((node) => (
                            <TreeNode
                                key={node.id}
                                node={node}
                                depth={0}
                                selectedId={selectedFolder}
                                onSelect={setSelectedFolder}
                            />
                        ))}
                    </div>
                </div>

                {/* ── Bảng danh sách file ── */}
                <div className="flex-1 bg-white rounded-xl border border-gray-200 flex flex-col min-w-0">
                    <div className="px-5 pt-4 pb-3">
                        <h2 className="text-base font-semibold text-gray-900">Tất cả file</h2>
                    </div>
                    <div className="flex-1 overflow-auto">
                        <table className="w-full text-sm">
                            <thead>
                            <tr className="text-left text-xs text-gray-400 border-y border-gray-100">
                                <th className="font-medium px-5 py-2.5">Tên</th>
                                <th className="font-medium px-5 py-2.5">Chủ sở hữu</th>
                                <th className="font-medium px-5 py-2.5">Người tải lên</th>
                                <th className="font-medium px-5 py-2.5">Cập nhật</th>
                                <th className="font-medium px-5 py-2.5">Kích thước</th>
                                <th className="font-medium px-5 py-2.5 w-8"></th>
                            </tr>
                            </thead>
                            <tbody>
                            {FILES.map((file) => (
                                <tr
                                    key={file.id}
                                    className="border-b border-gray-50 last:border-0 hover:bg-gray-50/60 transition-colors"
                                >
                                    <td className="px-5 py-2.5">
                                        <div className="flex items-center gap-2 min-w-0">
                                            <FileTypeIcon type={file.type} />
                                            <span className="text-gray-800 truncate">{file.name}</span>
                                        </div>
                                    </td>
                                    <td className="px-5 py-2.5 text-gray-600 whitespace-nowrap">{file.owner}</td>
                                    <td className="px-5 py-2.5">
                                        <div className="min-w-0">
                                            <p className="text-gray-700 truncate">{file.uploadedByName}</p>
                                            <p className="text-xs text-gray-400 truncate">{file.uploadedByEmail}</p>
                                        </div>
                                    </td>
                                    <td className="px-5 py-2.5 text-gray-500 whitespace-nowrap">{file.updatedAt}</td>
                                    <td className="px-5 py-2.5 text-gray-500 whitespace-nowrap">{file.size}</td>
                                    <td className="px-5 py-2.5">
                                        <button className="p-1 rounded hover:bg-gray-100 text-gray-400 hover:text-gray-600 transition-colors">
                                            <MoreVertical className="w-4 h-4" strokeWidth={2} />
                                        </button>
                                    </td>
                                </tr>
                            ))}
                            </tbody>
                        </table>
                    </div>

                    {/* ── Dung lượng sử dụng ── */}
                    <div className="px-5 py-3.5 border-t border-gray-100 flex items-center gap-3">
                        <span className="text-sm text-gray-500 whitespace-nowrap">
                            Đã sử dụng: {usedGb} GB / {totalGb} GB
                        </span>
                        <div className="flex-1 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                            <div
                                className="h-full bg-blue-500 rounded-full"
                                style={{ width: `${usedPct}%` }}
                            />
                        </div>
                        <span className="text-sm text-gray-500">{usedPct}%</span>
                    </div>
                </div>
            </div>

            {showCreateFolder && (
                <CreateFolderModal
                    parentFolderName={currentFolderName}
                    onClose={() => setShowCreateFolder(false)}
                    onCreate={(name) => {
                        // TODO: gọi API tạo thư mục, ví dụ POST /api/folders { name, parentId: selectedFolder }
                        console.log('Tạo thư mục:', name, 'trong', selectedFolder);
                    }}
                />
            )}

            {showUploadFile && (
                <UploadFileModal
                    parentFolderName={currentFolderName}
                    onClose={() => setShowUploadFile(false)}
                    onUpload={(files) => {
                        // TODO: gọi API upload, ví dụ POST /api/files/upload (FormData) với folderId: selectedFolder
                        console.log('Upload files:', files, 'vào', selectedFolder);
                    }}
                />
            )}
        </div>
    );
}