'use client';
import { useEffect, useRef, useState } from 'react';
import { Folder, FileText, ChevronRight, ChevronDown, Menu, MoreVertical, ShieldCheck, Upload, Edit3, Trash2 } from 'lucide-react';
import { FOLDER_TREE } from '@/lib/fake-data';
import { FOLDER_TREE_WITH_FILES } from '@/lib/fake-data';

type FolderNode = {
    id: string;
    name: string;
    type?: 'folder' | 'file'; // mặc định 'folder' nếu không có
    children?: FolderNode[];
};

interface FolderTreeProps {
    selectedId: string;
    onSelect: (id: string, name: string) => void;
    onManagePermission: (id: string, name: string) => void;
}

function FolderContextMenu({
                               node,
                               onClose,
                               onManagePermission,
                           }: {
    node: FolderNode;
    onClose: () => void;
    onManagePermission: (id: string, name: string) => void;
}) {
    const menuRef = useRef<HTMLDivElement>(null);
    const isFile = node.type === 'file';

    useEffect(() => {
        function handleClickOutside(e: MouseEvent) {
            if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
                onClose();
            }
        }
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, [onClose]);

    return (
        <div
            ref={menuRef}
            className="absolute right-2 top-8 z-20 w-48 bg-white rounded-lg border border-gray-200 shadow-lg py-1"
        >
            {!isFile && (
                <button
                    onClick={() => {
                        onClose();
                        console.log('Upload vào', node.id);
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 text-sm text-gray-700 hover:bg-gray-50 transition-colors"
                >
                    <Upload className="w-4 h-4 text-gray-400" strokeWidth={2} />
                    Upload file
                </button>
            )}
            <button
                onClick={() => {
                    onClose();
                    console.log('Đổi tên', node.id);
                }}
                className="w-full flex items-center gap-2 px-3 py-2 text-sm text-gray-700 hover:bg-gray-50 transition-colors"
            >
                <Edit3 className="w-4 h-4 text-gray-400" strokeWidth={2} />
                Đổi tên
            </button>
            <button
                onClick={() => {
                    onClose();
                    onManagePermission(node.id, node.name);
                }}
                className="w-full flex items-center gap-2 px-3 py-2 text-sm text-blue-600 hover:bg-blue-50 transition-colors"
            >
                <ShieldCheck className="w-4 h-4" strokeWidth={2} />
                {isFile ? 'Phân quyền tài liệu' : 'Phân quyền thư mục'}
            </button>
            <div className="my-1 border-t border-gray-100" />
            <button
                onClick={() => {
                    onClose();
                    console.log('Xóa', node.id);
                }}
                className="w-full flex items-center gap-2 px-3 py-2 text-sm text-red-600 hover:bg-red-50 transition-colors"
            >
                <Trash2 className="w-4 h-4" strokeWidth={2} />
                {isFile ? 'Xóa file' : 'Xóa thư mục'}
            </button>
        </div>
    );
}

function TreeNode({
                      node,
                      depth,
                      selectedId,
                      onSelect,
                      collapsed,
                      onManagePermission,
                  }: {
    node: FolderNode;
    depth: number;
    selectedId: string;
    onSelect: (id: string, name: string) => void;
    collapsed: boolean;
    onManagePermission: (id: string, name: string) => void;
}) {
    const [open, setOpen] = useState(true);
    const [menuOpen, setMenuOpen] = useState(false);
    const isFile = node.type === 'file';
    const hasChildren = !isFile && !!node.children?.length;
    const isSelected = selectedId === node.id;

    return (
        <div>
            <div
                className={`group relative flex items-center rounded-md mb-1 transition-colors duration-150 ${
                    isSelected ? 'bg-blue-50' : 'hover:bg-gray-50'
                }`}
            >
                <button
                    onClick={() => {
                        onSelect(node.id, node.name);
                        if (hasChildren) setOpen((o) => !o);
                    }}
                    title={collapsed ? node.name : undefined}
                    className={`flex-1 min-w-0 flex items-center gap-1.5 py-1.5 text-sm ${
                        collapsed ? 'justify-center px-0' : 'px-2'
                    } ${isSelected ? 'text-blue-700 font-medium' : 'text-gray-600'}`}
                    style={collapsed ? undefined : { paddingLeft: 8 + depth * 14 }}
                >
                    {!collapsed && (
                        <span className="w-3.5 shrink-0 flex items-center justify-center">
                            {hasChildren &&
                                (open ? (
                                    <ChevronDown className="w-3.5 h-3.5 text-gray-400" strokeWidth={2} />
                                ) : (
                                    <ChevronRight className="w-3.5 h-3.5 text-gray-400" strokeWidth={2} />
                                ))}
                        </span>
                    )}
                    {isFile ? (
                        <FileText className="w-4 h-4 shrink-0 text-gray-400" strokeWidth={2} />
                    ) : (
                        <Folder className="w-4 h-4 shrink-0 text-gray-400" strokeWidth={2} />
                    )}
                    {!collapsed && <span className="truncate">{node.name}</span>}
                </button>

                {!collapsed && (
                    <button
                        onClick={(e) => {
                            e.stopPropagation();
                            setMenuOpen((o) => !o);
                        }}
                        aria-label={isFile ? 'Tùy chọn file' : 'Tùy chọn thư mục'}
                        className={`p-1 mr-1 rounded hover:bg-gray-200/60 text-gray-400 hover:text-gray-600 shrink-0 transition-opacity ${
                            menuOpen ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'
                        }`}
                    >
                        <MoreVertical className="w-3.5 h-3.5" strokeWidth={2} />
                    </button>
                )}

                {menuOpen && (
                    <FolderContextMenu
                        node={node}
                        onClose={() => setMenuOpen(false)}
                        onManagePermission={onManagePermission}
                    />
                )}
            </div>

            {!collapsed && hasChildren && open && (
                <div>
                    {node.children!.map((child) => (
                        <TreeNode
                            key={child.id}
                            node={child}
                            depth={depth + 1}
                            selectedId={selectedId}
                            onSelect={onSelect}
                            collapsed={collapsed}
                            onManagePermission={onManagePermission}
                        />
                    ))}
                </div>
            )}
        </div>
    );
}

export default function FolderTree({ selectedId, onSelect, onManagePermission }: FolderTreeProps) {
    const [collapsed, setCollapsed] = useState(false);

    return (
        <div
            className={`shrink-0 bg-white rounded-xl border border-gray-200 flex flex-col h-full transition-all duration-200 ${
                collapsed ? 'w-14' : 'w-64'
            }`}
        >
            <div className={`flex items-center pt-3 pb-2 ${collapsed ? 'justify-center px-0' : 'justify-between px-3'}`}>
                {!collapsed && (
                    <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide px-2">Thư mục</p>
                )}
                <button
                    onClick={() => setCollapsed((c) => !c)}
                    className="p-1.5 rounded-md hover:bg-gray-100 text-gray-500"
                    title={collapsed ? 'Mở rộng' : 'Thu gọn'}
                >
                    <Menu className="w-4 h-4" strokeWidth={2} />
                </button>
            </div>

            <div className="flex-1 overflow-y-auto px-2 pb-3">
                <button
                    onClick={() => onSelect('all', 'Tất cả file')}
                    title={collapsed ? 'Tất cả file' : undefined}
                    className={`w-full flex items-center gap-1.5 py-1.5 rounded-md text-sm mb-1 transition-colors duration-150 ${
                        collapsed ? 'justify-center px-0' : 'px-2'
                    } ${selectedId === 'all' ? 'bg-blue-50 text-blue-700 font-medium' : 'text-gray-600 hover:bg-gray-50'}`}
                >
                    {!collapsed && <span className="w-3.5 shrink-0" />}
                    <Folder className="w-4 h-4 shrink-0 text-gray-400" strokeWidth={2} />
                    {!collapsed && 'Tất cả file'}
                </button>
                {FOLDER_TREE_WITH_FILES.map((node) => (
                    <TreeNode
                        key={node.id}
                        node={node}
                        depth={0}
                        selectedId={selectedId}
                        onSelect={onSelect}
                        collapsed={collapsed}
                        onManagePermission={onManagePermission}
                    />
                ))}
            </div>
        </div>
    );
}