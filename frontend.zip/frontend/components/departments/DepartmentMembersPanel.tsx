// components/departments/DepartmentMembersPanel.tsx
'use client';
import { useState } from 'react';
import { Users, X } from 'lucide-react';
import type { Department, DepartmentRole } from '@/lib/types';

export default function DepartmentMembersPanel({
                                                   department,
                                                   onAddMember,
                                                   onRemoveMember,
                                                   onChangeRole,
                                               }: {
    department: Department;
    onAddMember: (query: string) => void;
    onRemoveMember: (userId: string) => void;
    onChangeRole: (userId: string, role: DepartmentRole) => void;
}) {
    const [query, setQuery] = useState('');

    return (
        <div className="flex-1 bg-white rounded-xl border border-gray-200 p-5 min-w-0">
            <div className="flex items-center gap-3 mb-1">
                <div className="w-9 h-9 rounded-full bg-blue-50 flex items-center justify-center shrink-0">
                    <Users className="w-4.5 h-4.5 text-blue-600" strokeWidth={2} />
                </div>
                <div>
                    <p className="text-base font-semibold text-gray-900">{department.name}</p>
                    <p className="text-xs text-gray-400 mt-0.5">{department.members.length} thành viên</p>
                </div>
            </div>

            <div className="flex items-center gap-2 my-4">
                <input
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder={`Thêm thành viên vào ${department.name}...`}
                    className="flex-1 px-3 py-2 rounded-lg border border-gray-200 text-sm outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-100 transition-colors"
                />
                <button
                    onClick={() => {
                        if (!query.trim()) return;
                        onAddMember(query.trim());
                        setQuery('');
                    }}
                    disabled={!query.trim()}
                    className="px-4 py-2 rounded-lg bg-blue-600 text-sm font-medium text-white hover:bg-blue-700 disabled:opacity-40 transition-colors shrink-0"
                >
                    Thêm
                </button>
            </div>

            <div className="border border-gray-100 rounded-lg divide-y divide-gray-50">
                {department.members.map((member) => (
                    <div key={member.userId} className="flex items-center gap-3 px-3 py-2.5">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 text-xs font-bold ${member.avatarColor}`}>
                            {member.avatarInitial}
                        </div>
                        <div className="flex-1 min-w-0">
                            <p className="text-sm text-gray-800 truncate">{member.name}</p>
                            <p className="text-xs text-gray-400 truncate">{member.email}</p>
                        </div>
                        <select
                            value={member.role}
                            onChange={(e) => onChangeRole(member.userId, e.target.value as DepartmentRole)}
                            className="text-xs border border-gray-200 rounded-full px-2.5 py-1 text-gray-600 outline-none shrink-0"
                        >
                            <option value="Trưởng phòng">Trưởng phòng</option>
                            <option value="Thành viên">Thành viên</option>
                        </select>
                        <button
                            onClick={() => onRemoveMember(member.userId)}
                            aria-label={`Xóa ${member.name} khỏi phòng ban`}
                            className="p-1 rounded hover:bg-gray-100 text-gray-400 hover:text-gray-600 transition-colors shrink-0"
                        >
                            <X className="w-4 h-4" strokeWidth={2} />
                        </button>
                    </div>
                ))}
                {department.members.length === 0 && (
                    <p className="text-sm text-gray-400 text-center py-8">Chưa có thành viên nào</p>
                )}
            </div>
        </div>
    );
}