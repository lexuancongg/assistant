// components/departments/DepartmentList.tsx
'use client';
import { Users, Plus } from 'lucide-react';
import type { Department } from '@/lib/types';

export default function DepartmentList({
                                           departments,
                                           selectedId,
                                           onSelect,
                                           onCreate,
                                       }: {
    departments: Department[];
    selectedId: string;
    onSelect: (id: string) => void;
    onCreate: () => void;
}) {
    return (
        <div className="w-56 shrink-0 bg-white rounded-xl border border-gray-200 p-3 flex flex-col">
            <div className="flex items-center justify-between mb-2 px-1">
                <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide">Phòng ban</p>
                <button
                    onClick={onCreate}
                    aria-label="Tạo phòng ban"
                    className="p-1 rounded hover:bg-gray-100 text-gray-400 hover:text-gray-600 transition-colors"
                >
                    <Plus className="w-4 h-4" strokeWidth={2} />
                </button>
            </div>

            <div className="flex flex-col gap-0.5">
                {departments.map((dept) => (
                    <button
                        key={dept.id}
                        onClick={() => onSelect(dept.id)}
                        className={`flex items-center gap-2 px-2 py-2 rounded-lg text-sm transition-colors ${
                            selectedId === dept.id
                                ? 'bg-blue-50 text-blue-700 font-medium'
                                : 'text-gray-600 hover:bg-gray-50'
                        }`}
                    >
                        <Users className="w-4 h-4 shrink-0" strokeWidth={2} />
                        <span className="flex-1 text-left truncate">{dept.name}</span>
                        <span className="text-xs text-gray-400">{dept.members.length}</span>
                    </button>
                ))}
            </div>
        </div>
    );
}